//
//  epsilon_calc.hpp
//  
//
//  Created by Sara Verheyleweghen on 03/03/2020.
//

#ifndef epsilon_calc_hpp
#define epsilon_calc_hpp

#include <stdio.h>
#include <math.h>
#include "trivialfuncs.h"
#include "linsys_solvers.h"
#include "o_funcs.h"

void calc_epsilon_pred (double** epsilon1, double** epsilon0,double** k0, double** k1, double** rho, double** u, double** phi, double** res1, double** res0, 
double C1, double C2, double C3, double Cnu, double sigma_e, double** nu, double** nu_t0,double** nu_t1, double** delta_x, 
double** delta_y, int n, int m, int pm_res, grid cells, double dt, double* yval);


void calc_epsilon_corr (double** epsilon1, double** epsilon0, double** k0, double** k1, double** rho, double** u, double** phi, double** res1, double** res0, 
double C1, double C2, double C3, double Cnu, double sigma_e, double** nu, double** nu_t0,double** nu_t1, double** delta_x, 
double** delta_y,  int n, int m, int pm_res, grid cells, double dt, double* yval); 


void res_epsilon_compu(double** res_epsilon, double** f1, double** f2, double** epsilon, double** rho, double** phi, double** u, double** v,double C1, double C2, double C3,double sigma_e, double** nu,double** nu_t, double** delta_x, double** delta_y, double** k, grid cells, int n, int m);

void epsilon_constr_abc ( double* a, double* b, double* c, int m, int pm_res, double** rho, double** u, double** k0, double** k1, double** epsilon0, double** nu, double** nu_t1,
 double sigma_e, double** phi, double C2, double C3, double Cnu, double** delta_x, double** delta_y, grid cells, int i, double dt, int n, double* yval);

void epsilon_constr_rhs_pred (double* r, int m, int pm_res, double** epsilon, double** k0, double** u, double** res1, double** res0, double** rho, double** phi,double** nu, 
double** nu_t0, double sigma_e, double C2, double C3, double Cnu, double** delta_x, double** delta_y,grid cells, int i, double dt,int n, double* yval);

void epsilon_constr_rhs_corr (double* r, int m, int pm_res, double** epsilon, double** k0, double** u, double** res1, double** res0, double** rho, 
double** phi,double** nu, double** nu_t0, double sigma_e, double C2, double C3, double Cnu, double** delta_x, double** delta_y, grid cells, int i, double dt,int n, double* yval); 
#endif /* epsilon_calc_hpp */
