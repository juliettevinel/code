/*
 *  epsilon_calc.cpp
 *
 *
 * Created on : June 9, 2020
 *  Authors : sverhey and jvinel
 */

#include "./headers/epsilon_calc.hpp"


void calc_epsilon_pred (double** epsilon1, double** epsilon0, double** rho, double** phi, double** res1, double** res0, double C1, double C2, double C3, double sigma_e, double** f3, double** nu, double** nu_tot0,double** nu_tot1, double** k, double** delta_x, double** delta_y,double* y_val, double* u_tau, int n, int m, int pm_res, grid cells, double dt) {
    
    
    double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;
    
    mat_a = new double[m];  mat_a--;
    mat_b = new double[m];  mat_b--;
    mat_c = new double[m];  mat_c--;
    rhs = new double[m]; rhs--;
    sol = new double[m]; sol--;
    gam = new double[m]; gam--;
    
    // flag detecting errors in tri_dag
    int flag = 0;
    //double rhsmax=0;
    
    //------------------
    // start
    //------------------
    
    
    for (int i=1 ; i<=n ; i++) {
        
        
        epsilon_constr_abc ( mat_a,  mat_b,  mat_c, m,  pm_res, epsilon0,k, rho,  nu,  nu_tot1,  sigma_e,  phi, C2,C3, f3, delta_x, delta_y, y_val, u_tau,cells, i,  dt,n);
        epsilon_constr_rhs_pred ( rhs,  m,  pm_res,  epsilon0,k,  res1, res0,  rho, phi, nu, nu_tot0, sigma_e, C2,C3, f3, delta_x,delta_y,y_val, u_tau,cells,  i,  dt,n);
        
        tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;
        
        for (int j=1 ; j<=m ; j++){
            epsilon1[i][j] = sol[j];
            if (sol[j]<-1e-150)
                epsilon1[i][j] = 0.;
            
            //if (sol[j]<=0.)
            //printf("\n eps neg i: %d j: %d \n ", i ,j);
            if (isnan(sol[j]))
                printf("\n eps NaN i: %d j: %d \n ", i ,j);
            if (isinf(sol[j]))
                printf("\n eps Inf i: %d j: %d \n ", i ,j);
        }
        
    }
    
    
    if (flag == 1)
        cout << "ERROR IN calc_epsilon_pred" << endl;
    
    
    mat_a++ ; delete [] mat_a;
    mat_b++ ; delete [] mat_b;
    mat_c++ ; delete [] mat_c;
    rhs++ ; delete [] rhs ;
    sol++ ; delete [] sol ;
    gam++ ; delete [] gam;
    
}



void calc_epsilon_corr (double** epsilon1, double** epsilon0, double** rho, double** phi, double** res1, double** res0, double C1, double C2, double C3, double sigma_e, double** f3, double** nu, double** nu_tot0,double** nu_tot1, double** k, double** delta_x, double** delta_y,  double* y_val, double* u_tau,int n, int m, int pm_res, grid cells, double dt) {
    
    
    
    double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;
    
    mat_a = new double[m];  mat_a--;
    mat_b = new double[m];  mat_b--;
    mat_c = new double[m];  mat_c--;
    rhs = new double[m]; rhs--;
    sol = new double[m]; sol--;
    gam = new double[m]; gam--;
    
    // flag detecting errors in tri_dag
    int flag = 0;
    
    
    //------------------
    // start
    //------------------
    
    
    for (int i=1 ; i<=n ; i++) {
        
        epsilon_constr_abc ( mat_a,  mat_b,  mat_c, m,  pm_res,epsilon0,k,  rho,  nu,  nu_tot1,  sigma_e, phi,C2,C3,f3, delta_x,delta_y,y_val,u_tau, cells, i,  dt,n);
        epsilon_constr_rhs_corr(rhs, m, pm_res,  epsilon0,k,  res1,  res0, rho,  phi, nu,  nu_tot0,  sigma_e,C2,C3,f3, delta_x,delta_y,y_val, u_tau,cells,  i, dt,n);
        
        tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;
        
        for (int j=1 ; j<=m ; j++){
            epsilon1[i][j] = sol[j];
            if (sol[j]<-1e-150)
                epsilon1[i][j] = 0.;
            //if (sol[j]<0.)
            //printf("\n eps neg i: %d j: %d \n ", i ,j);
        }
        
    }
    
    
    if (flag == 1)
        cout << "ERROR IN calc_epsilon_corr" << endl;
    
    
    mat_a++ ; delete [] mat_a;
    mat_b++ ; delete [] mat_b;
    mat_c++ ; delete [] mat_c;
    rhs++ ; delete [] rhs ;
    sol++ ; delete [] sol ;
    gam++ ; delete [] gam;
    
    
}


void res_epsilon_compu(double** res_epsilon, double** f1, double** f2, double** epsilon, double** rho, double** phi, double** u, double** v,double C1, double C2, double C3,double sigma_e, double** f3, double** nu,double** nu_t,double** nu_tot, double** delta_x, double** delta_y, double** k,double* y_val, double* u_tau, grid cells, int n, int m) {
    
    double conva, convb, conv_term ;
    double diffa, diffb, diff_term ;
    double coeff_C1, coeff_C2, termeC1a, termeC1b, termeC1c, termeC2a, termeC2c, termeC3, termeE;
    double res_max=0;
    
    cell pt ;
    
    
    
    for (int i=1 ; i<=n ; i++) {
        for (int j=1 ; j<=m ; j++) {
            
            pt.i = i;
            pt.j = j;
            
            // convective term
            if (u[i][j]>=0.)
                conva= u[i][j]*rho[i][j]*phi[i][j]* ((epsilon[i][j] - epsilon[i-1][j])/(cells.ri[i-1] + cells.ri[i] ));
            
            if(u[i][j]<0.)
                conva= u[i][j]*rho[i][j]*phi[i][j]* ((epsilon[i+1][j] - epsilon[i][j])/(cells.ri[i+1] + cells.ri[i] ));
            
            if(v[i][j]>=0.)
                convb= v[i][j]*rho[i][j]*phi[i][j]* ((epsilon[i][j] - epsilon[i][j-1])/(cells.rj[j-1] + cells.rj[j] ));
            
            if(v[i][j]<0.)
                convb= v[i][j]*rho[i][j]*phi[i][j]* ((epsilon[i][j+1] - epsilon[i][j])/(cells.rj[j+1] + cells.rj[j] ));
            
            conv_term = -(conva + convb) ;
            
            
            // diffusive term
            
            diffa = valfor(phi,nu_tot, pt,cells) * derxfor(epsilon, pt, cells) /2. /cells.ri[i]  ;
            
            diffb = valback(phi,nu_tot, pt,cells) * derxback(epsilon, pt,cells) /2. /cells.ri[i] ;
            
            
            diff_term = rho[i][j]/Re * (diffa - diffb) ;
            
            // termes avec constantes C1, C2 et C5
            
            if (k[i][j] == 0. ){
                coeff_C1=0.;
                coeff_C2=0.;
                termeC3=0.;
            }
            else {
                coeff_C1 = C1*nu_t[i][j]*rho[i][j]*phi[i][j]*epsilon[i][j]/k[i][j]/Re;
                coeff_C2 = 2.*C2*epsilon[i][j]/k[i][j]/rho[i][j]/Re*nu_t[i][j]*rho[i][j];
                termeC3 = 0.;
                
            }
            
            
            
            termeC1a= coeff_C1*( 2.* derx(u,pt,cells)*derx(u,pt,cells)+ 2.*
                                dery(v,pt,cells)*dery(v,pt,cells)+ (dery(u,pt,cells) + derx(v,pt,cells))*(dery(u,pt,cells) + derx(v,pt,cells)));
            
            
            termeC1b= -2./3.*C1*phi[i][j]*epsilon[i][j]*rho[i][j]*( derx(u,pt,cells)+ dery(v,pt,cells));
            
            termeC1c= -2/3.* coeff_C1*( derx(u,pt,cells) + dery(v,pt,cells))*( derx(u,pt,cells) + dery(v,pt,cells));
            
            termeC2a=coeff_C2*(delta_x[i][j]*derx(u,pt,cells)+delta_y[i][j]*dery(v,pt,cells));
            
            
            
            termeC2c= -coeff_C2/3.*(delta_x[i][j]+delta_y[i][j])*( derx(u,pt,cells)+ dery(v,pt,cells));
            
            termeE = -2/Re*phi[i][j]*rho[i][j]*nu[i][j]*epsilon[i][j]/y_val[j]/y_val[j]*exp(-0.5*sqrt(Re)*u_tau[i]*y_val[j]/nu[i][j]);
            
            res_epsilon[i][j] = conv_term + diff_term + termeC1a +termeC1b+termeC2a+termeC3+termeC1c+termeC2c+termeE;
            res_max=max(res_max,abs(termeC3));
            
        }
    }
}


void epsilon_constr_abc ( double* a, double* b, double* c, int m, int pm_res, double** epsilon, double** k, double** rho, double** nu, double** nu_tot, double sigma_e, double** phi, double C2, double C3, double** f3, double** delta_x, double** delta_y,double* y_val, double* u_tau, grid cells, int i, double dt, int n) {
    
    double alpha, betta, termC3;
    
    cell pt;
    
    pt.i = i;
    
    for (int j=1 ; j<=m ; j++) {
        
        pt.j = j ;
        
        alpha = 0.5 /Re * dt * valtop(phi,nu_tot, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j+1]) ;
        
        betta = 0.5 /Re * dt * valbot(phi,nu_tot,pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j-1]) ;
        
        if (k[i][j] == 0.)
            termC3 = 0.;
        else
            termC3 = 0.5*dt/Re*C3*f3[i][j]*epsilon[i][j]/k[i][j]*phi[i][j]*rho[i][j];
        
        a[j] = - betta*rho[i][j] ;
        
        c[j] = - alpha*rho[i][j] ;
        
        b[j] = rho[i][j] * phi[i][j] + alpha*rho[i][j] + betta*rho[i][j] +1./3. *dt*C2*(delta_x[i][j]+delta_y[i][j])+termC3;
    }
    
    if (Bcomb_epsilon_b == 'o')
        // lower boundary
        b[1] += a[1];
    else if (Bcomb_epsilon_t == 'o')
        // upper boundary
        b[m] += c[m];
    
    else if (Bcomb_epsilon_b == 'd'|| Bcomb_epsilon_b == 'w')
        // lower boundary
        b[1] -= a[1];
    else if (Bcomb_epsilon_t == 'd' || Bcomb_epsilon_t == 'w')
        // upper boundary
        b[m] -= c[m];
    
    else
        cout << endl << "ERROR in the choice of bcomb_epsilon_t, in file epsilon_calc.cpp" << endl;
    
}

void epsilon_constr_rhs_pred (double* r, int m, int pm_res, double** epsilon, double** k, double** res1, double** res0, double** rho, double** phi,double** nu, double** nu_tot, double sigma_e, double C2, double C3, double** f3, double** delta_x, double** delta_y,double* y_val, double* u_tau,grid cells, int i, double dt,int n) {
    
    double term_n, term_s, termC3 ;
    
    cell pt;
    
    pt.i = i ;
    
    for (int j=1 ; j<=m ; j++) {
        
        pt.j = j;
        
        term_n = valtop(phi,nu_tot, pt,cells) * derytop(epsilon, pt,cells) /2. /cells.rj[j] ;
        
        term_s = valbot(phi,nu_tot,pt,cells) * derybot(epsilon, pt,cells) /2. /cells.rj[j] ;
        
        if (k[i][j] == 0.)
            termC3 = 0.;
        else
            termC3 = 0.5*dt/Re*f3[i][j]*epsilon[i][j]*epsilon[i][j]/k[i][j]*C3*phi[i][j]*rho[i][j];
        
        r[j] = rho[i][j] * phi[i][j] * epsilon[i][j]  + 1.5*dt*res1[i][j] - 0.5*dt*res0[i][j] +
        + dt*0.5 /Re * rho[i][j]*(term_n - term_s) - 1./3. *dt*C2*(delta_x[i][j]+delta_y[i][j])*epsilon[i][j]
        -termC3;
    }
    
    
    if (Bcomb_epsilon_b == 'd' ||Bcomb_epsilon_b == 'w' ) {
        
        pt.j = 1;
        r[1] += 2. * epsilon_val_b * 0.5 *dt /Re *rho[1][1] * valbot(phi,nu_tot, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;
    }
    else if (Bcomb_epsilon_t == 'd' || Bcomb_epsilon_t == 'w'){
        pt.j = m ;
        r[m] += 2. * epsilon_val_t * 0.5 *dt /Re * rho[1][1]*valtop(phi,nu_tot, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);
        
    }
    
}


void epsilon_constr_rhs_corr (double* r, int m, int pm_res, double** epsilon, double** k, double** res1, double** res0, double** rho, double** phi,double** nu, double** nu_tot, double sigma_e, double C2, double C3, double** f3, double** delta_x, double** delta_y,double* y_val, double* u_tau, grid cells, int i, double dt,int n) {
    
    double term_n, term_s,termC3 ;
    
    cell pt;
    
    pt.i = i ;
    
    for (int j=1 ; j<=m ; j++) {
        
        pt.j = j;
        
        term_n = valtop(phi,nu_tot, pt,cells) * derytop(epsilon, pt,cells) /2. /cells.rj[j] ;
        
        term_s = valbot(phi,nu_tot, pt,cells) * derybot(epsilon, pt,cells) /2. /cells.rj[j] ;
        
        if (k[i][j] == 0.)
            termC3 = 0.;
        else
            termC3 = 0.5*dt/Re*f3[i][j]*epsilon[i][j]*epsilon[i][j]/k[i][j]*C3*phi[i][j]*rho[i][j];
        
        
        r[j] = rho[i][j] * phi[i][j] * epsilon[i][j] + 0.5*dt*res1[i][j] + 0.5*dt*res0[i][j]
        + dt*0.5*rho[i][j] /Re * (term_n - term_s)- 1./3. *dt*C2*(delta_x[i][j]+delta_y[i][j])*epsilon[i][j]
        -termC3;
    }
    
    
    
    if (Bcomb_epsilon_b == 'd' || Bcomb_epsilon_b == 'w') {
        
        pt.j = 1;
        r[1] += 2. * epsilon_val_b * 0.5 *dt /Re  *rho[1][1]* valbot(phi,nu_tot, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;
    }
    else if (Bcomb_epsilon_t == 'd'|| Bcomb_epsilon_t == 'w') {
        pt.j = m ;
        r[m] += 2. * epsilon_val_t * 0.5 *dt /Re * rho[1][1]*valtop(phi,nu_tot, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);
        
    }
}



