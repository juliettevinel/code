
#include "./headers/k_calc.h"


void calc_k_pred (double** k1, double** k0, double** rho, double** res_k1, double** res_k0, double** phi, double** nu, double** nu_t0, double** nu_t1,double sigma_k,
					double** delta_x, double** delta_y, double* y_val,int n, int m, int pm_res, grid cells, double dt) {

	double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;

	mat_a = new double[m];  mat_a--;
	mat_b = new double[m];  mat_b--;
	mat_c = new double[m];  mat_c--;
	rhs = new double[m]; rhs--;
	sol = new double[m]; sol--;
	gam = new double[m]; gam--;

	// flag detecting errors in tri_dag
	int flag = 0;

	//------------------
	// start
	//------------------
   
	for (int i=1 ; i<=n ; i++) {

	  k_constr_abc (mat_a, mat_b, mat_c, pm_res, rho, phi, delta_x, delta_y, nu, nu_t1, sigma_k, y_val,cells, i, dt, n, m) ;
	  k_constr_rhs_pred ( rhs, pm_res, res_k1, res_k0, nu, nu_t0, sigma_k, rho, delta_x, delta_y, k0, phi, y_val, cells, i , dt, n, m) ;

	  tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;

	  for (int j=1 ; j<=m ; j++)
	    k1[i][j] = sol[j] ;

	}


	if (flag == 1)
	  cout << "ERROR IN calc_t_pred" << endl;


	mat_a++ ; delete [] mat_a;
	mat_b++ ; delete [] mat_b;
	mat_c++ ; delete [] mat_c;
	rhs++ ; delete [] rhs ;
	sol++ ; delete [] sol ;
	gam++ ; delete [] gam;

}




void calc_k_corr (double** k1, double** k0, double** rho, double** res_k1, double** res_k0, double** phi, double** nu, double** nu_t0, double** nu_t1, double sigma_k,
					double** delta_x, double** delta_y,double* y_val, int n, int m, int pm_res, grid cells, double dt) {



	double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;

	mat_a = new double[m];  mat_a--;
	mat_b = new double[m];  mat_b--;
	mat_c = new double[m];  mat_c--;
	rhs = new double[m]; rhs--;
	sol = new double[m]; sol--;
	gam = new double[m]; gam--;

	// flag detecting errors in tri_dag
	int flag = 0;


	//------------------
	// start
	//------------------


	for (int i=1 ; i<=n ; i++) {
     
	  k_constr_abc (mat_a, mat_b, mat_c, pm_res, rho, phi, delta_x, delta_y, nu, nu_t1, sigma_k, y_val, cells, i, dt, n, m) ;
	  k_constr_rhs_corr ( rhs, pm_res, k0, res_k1, res_k0, nu, nu_t0,sigma_k, delta_x, delta_y, rho, phi, y_val, cells, i , dt,n ,m) ;

	  tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;

	  for (int j=1 ; j<=m ; j++)
	    k1[i][j] = sol[j] ;

	}


	if (flag == 1)
	  cout << "ERROR IN calc_t_corr" << endl;


	mat_a++ ; delete [] mat_a;
	mat_b++ ; delete [] mat_b;
	mat_c++ ; delete [] mat_c;
	rhs++ ; delete [] rhs ;
	sol++ ; delete [] sol ;
	gam++ ; delete [] gam;


}




void res_k_compu(double** res_k, double** f1, double** f2, double** k,double** epsilon, double** u, double** v, double** rho, double** phi,
						double** delta_x, double** delta_y, double** nu, double** nu_t, double sigma_k, grid cells, int n, int m) {

  double conva, convb, conv_term ;
  double diffa, diffb,  diff_term ;
  double sigma;
  double divergence;
  double drag;
 double** nu_tot;
 nu_tot= matrix_np(n+2,m+2) ;
  for(int i=0; i<=n+1; i++){
			for(int j=0; j<=m+1; j++){
				nu_tot[i][j] = nu[i][j]+nu_t[i][j]/sigma_k;
  }}

  //  double diffb ;

  cell pt ;

  for (int i=1 ; i<=n ; i++) {
    for (int j=1 ; j<=m ; j++) {

    	pt.i = i;
    	pt.j = j;

    	// convective term
		
		//nu_tot[i][j] = nu[i][j] + nu_t[i][j]/sigma_k;

		conva = ( f1[i][j] * derxfor(k, pt, cells) + f1[i-1][j] * derxback(k, pt, cells) ) /2. ;

		convb = ( f2[i][j] * derytop(k, pt, cells) + f2[i][j-1] * derybot(k, pt, cells) ) /2. ;

		conv_term = -(conva + convb) ;


      	  // diffusive term

		diffa = valfor(phi,nu_tot, pt,cells) * derxfor(k, pt, cells) /2. /cells.ri[i]  ;

		diffb = valback(phi,nu_tot, pt,cells) * derxback(k, pt,cells) /2. /cells.ri[i] ;

      
		diff_term = 1./Re * (diffa - diffb) ;
	  
		// sigma
		divergence = derx(u,pt,cells)+dery(v,pt,cells);
		sigma = (derx(u,pt,cells)-1./3.*divergence)*derx(u,pt,cells)+1./2.*(derx(v,pt,cells)+dery(u,pt,cells))*derx(v,pt,cells) 
			+ 1./2.*(derx(v,pt,cells)+dery(u,pt,cells))*dery(u,pt,cells) + (dery(v,pt,cells)-1./3.*divergence)*dery(v,pt,cells);
	  
		// drag
		drag = -delta_x[i][j]*(derx(u,pt,cells)-1./3.*divergence)-delta_y[i][j]*(dery(v,pt,cells)-1./3.*divergence);
      
		res_k[i][j] = conv_term+ rho[i][j]*(diff_term - phi[i][j]*epsilon[i][j] +phi[i][j]/Re*2*nu_t[i][j]*sigma
		- 2./3.*k[i][j]*phi[i][j]*divergence) + drag/Re*2*nu_t[i][j];
    }
  }
     delmat_np(nu_tot, n+2,m+2);
}



void k_constr_abc ( double* a, double* b, double* c, int pm_res, double** rho, double** phi, double** delta_x, double** delta_y, double** nu, double** nu_t, double sigma_k, double* y_val,grid cells, int i, double dt, int n, int m) {

  double alpha, betta;
   double** nu_tot;
  nu_tot= matrix_np(n+2,m+2) ;
  for(int i=0; i<=n+1; i++){
			for(int j=0; j<=m+1; j++){
				nu_tot[i][j] = nu[i][j]+nu_t[i][j]/sigma_k;
  }}

  cell pt;

  pt.i = i;

  for (int j=1 ; j<=m ; j++) {

	pt.j = j ;

	/*
    if (j == pm_res) {
    	alpha = 0.5 /Re /Pr * dt * valtop(k, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j+1]) ;

    	betta = 0.5 /Re /Pr * dt * valbot(phi,k, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j-1]) ;
     }
    else if (j == pm_res+1) {
    	alpha = 0.5 /Re /Pr * dt * valtop(phi,k, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j+1]) ;

    	betta = 0.5 /Re /Pr * dt * valbot(k, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j-1]) ;
    }
	*/
	//    else {
    	alpha = 0.5 /Re * dt * valtop(phi,nu_tot, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j+1])*rho[i][j] ;

    	betta = 0.5 /Re * dt * valbot(phi,nu_tot, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j-1])*rho[i][j] ;
	//    }

    a[j] = - betta ;

    c[j] = - alpha ;

      b[j] = rho[i][j] * phi[i][j] + alpha + betta - 0.5*dt*2./3.*(delta_x[i][j]+delta_y[i][j]);//+ dt* rho[i][j]* nu[i][j]/y_val[j]/y_val[j];

  }

  if (Bcomb_kb == 'o')
	  // lower boundary
	  b[1] += a[1];
  else if (Bcomb_kt == 'o')
	  // upper boundary
	  b[m] += c[m];
  
  else if (Bcomb_kb == 'w'||Bcomb_kb == 'd' )
	  // lower boundary
	  b[1] -= a[1];
  else if (Bcomb_kt == 'w'||Bcomb_kt == 'd')
	  // upper boundary
	  b[m] -= c[m];
  
  else
	  cout << endl << "ERROR in the choice of bcomb_kt, in file k_calc.cpp" << endl;
 delmat_np(nu_tot, n+2,m+2);
}



void k_constr_rhs_pred (double* r, int pm_res, double** res1, double** res0, double** nu, double** nu_t, double sigma_k, double** rho, double** delta_x, double** delta_y,
								double** k, double** phi,double* y_val, grid cells, int i, double dt, int n, int m) {

  double term_n, term_s ;
  double drag ;
   double** nu_tot;
  nu_tot= matrix_np(n+2,m+2) ;
  for(int i=0; i<=n+1; i++){
			for(int j=0; j<=m+1; j++){
				nu_tot[i][j] = nu[i][j]+nu_t[i][j]/sigma_k;
  }}
  cell pt;

  pt.i = i ;

  for (int j=1 ; j<=m ; j++) {

	  pt.j = j;

	  /*
    if (j == pm_res) {
    	term_n = valtop(k, pt,cells) * derytop(temp, pt,cells) /2. /cells.rj[j] ;

    	term_s = valbot(phi,k, pt,cells) * derybot(temp, pt,cells) /2. /cells.rj[j] ;
    }   
    else if (j == pm_res+1) {
    	term_n = valtop(phi,k, pt,cells) * derytop(temp, pt,cells) /2. /cells.rj[j] ;

    	term_s = valbot(phi,k, pt,cells) * derybot(temp, pt,cells) /2. /cells.rj[j] ;
    }
	  */
	  //    else {
      term_n = valtop(phi,nu_tot, pt,cells) * derytop(k, pt,cells) /2. /cells.rj[j] ;

      term_s = valbot(phi,nu_tot, pt,cells) * derybot(k, pt,cells) /2. /cells.rj[j] ;
      //    }
	  
	  drag =2./3.*(delta_x[i][j]+delta_y[i][j])*k[i][j];

    r[j] =  rho[i][j] * phi[i][j] * k[i][j]  + 1.5*dt*res1[i][j] - 0.5*dt*res0[i][j] +  0.5*dt*drag
      + dt*0.5 /Re *rho[i][j] * (term_n - term_s);//- dt*rho[i][j]*nu[i][j]*k[i][j]/y_val[j]/y_val[j] ;

  }

  

  if (Bcomb_kb == 'd'|| Bcomb_kb == 'w') {

	pt.j = 1;
    r[1] += 2. * kval_b * 0.5 *dt /Re * rho[1][1]*valbot(phi,nu_tot, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;
  }
     else if (Bcomb_kt == 'd'|| Bcomb_kt == 'w'){
    pt.j = m ;
    r[m] += 2. * kval_t * 0.5 *dt /Re *rho[1][1]*valtop(phi,nu_tot, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);

  }
 delmat_np(nu_tot, n+2,m+2);
}



void k_constr_rhs_corr (double* r, int pm_res, double** k, double** res1, double** res0, double** nu, double** nu_t, double sigma_k, double** delta_x, double** delta_y,
								double** rho, double** phi, double* y_val, grid cells, int i, double dt, int n, int m) {

  double term_n, term_s ;
	double drag;
	   double** nu_tot;
      nu_tot= matrix_np(n+2,m+2) ;
  for(int i=0; i<=n+1; i++){
			for(int j=0; j<=m+1; j++){
				nu_tot[i][j] = nu[i][j]+nu_t[i][j]/sigma_k;
  }}
  cell pt;

  pt.i = i ;

  for (int j=1 ; j<=m ; j++) {

	  pt.j = j;

	  /*
    if (j == pm_res) {
    	term_n = valtop(k, pt,cells) * derytop(temp, pt,cells) /2. /cells.rj[j] ;

    	term_s = valbot(phist,k, pt,cells) * derybot(temp, pt,cells) /2. /cells.rj[j] ;
    }   
    else if (j == pm_res+1) {
    	term_n = valtop(phist,k, pt,cells) * derytop(temp, pt,cells) /2. /cells.rj[j] ;

    	term_s = valbot(phist,k, pt,cells) * derybot(temp, pt,cells) /2. /cells.rj[j] ;
    }
	  */
	  //    else {
      term_n = valtop(phi,nu_tot, pt,cells) * derytop(k, pt,cells) /2. /cells.rj[j] ;

      term_s = valbot(phi,nu_tot, pt,cells) * derybot(k, pt,cells) /2. /cells.rj[j] ;
      //    }
	  
	  drag =2./3.*(delta_x[i][j]+delta_y[i][j])*k[i][j];

    r[j] =  rho[i][j] * phi[i][j] * k[i][j]  + 0.5*dt*res1[i][j] + 0.5*dt*res0[i][j] +  0.5*dt*drag
      + dt*0.5 /Re *rho[i][j] * (term_n - term_s);//- dt*rho[i][j]*nu[i][j]*k[i][j]/y_val[j]/y_val[j] ;

  }

  
  if (Bcomb_kb == 'd' ||Bcomb_kb == 'w') {

	pt.j = 1;
    r[1] += 2. * kval_b * 0.5 *dt /Re*rho[1][1]*valbot(phi,nu_tot, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;
  }
  else if (Bcomb_kt == 'd' || Bcomb_kb == 'w') {
    pt.j = m ;
    r[m] += 2. * kval_t * 0.5 *dt /Re  *rho[1][1]*valtop(phi,nu_tot, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);

  }
 delmat_np(nu_tot, n+2,m+2);
}



