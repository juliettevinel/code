//
//  epsilon_calc.cpp
//
//
//  Created by Sara Verheyleweghen on 03/03/2020.
//

#include "./headers/epsilon_calc.hpp"


void calc_epsilon_pred (double** epsilon1, double** epsilon0, double** rho, double** phi, double** res1, double** res0, double C1, double C2, double C3, double sigma_e, double** nu, double** nu_t0,double** nu_t1, double** k, double** delta_x, double** delta_y,double* y_val, double** u_tau, int n, int m, int pm_res, grid cells, double dt) {
    
    
    
    
    double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;
    
    mat_a = new double[m];  mat_a--;
    mat_b = new double[m];  mat_b--;
    mat_c = new double[m];  mat_c--;
    rhs = new double[m]; rhs--;
    sol = new double[m]; sol--;
    gam = new double[m]; gam--;
    
    // flag detecting errors in tri_dag
    int flag = 0;
    double rhsmax=0;
    
    //------------------
    // start
    //------------------
    
    
    for (int i=1 ; i<=n ; i++) {
        
        
        
        epsilon_constr_abc ( mat_a,  mat_b,  mat_c, m,  pm_res,  rho,  nu,  nu_t1,  sigma_e,  phi, C2, delta_x, delta_y, y_val, u_tau,cells, i,  dt,n);
        epsilon_constr_rhs_pred ( rhs,  m,  pm_res,  epsilon0,  res1, res0,  rho, phi, nu, nu_t0, sigma_e, C2, delta_x,delta_y,y_val, u_tau,cells,  i,  dt,n);
        
        tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;
        
        for (int j=1 ; j<=m ; j++){
            epsilon1[i][j] = sol[j] ;
            rhsmax = max(rhsmax,abs(rhs[j]));
            
        }
        
    }
    printf("\n rhsmaxpred = %f \n", rhsmax);
    
    if (flag == 1)
        cout << "ERROR IN calc_epsilon_pred" << endl;
    
    
    mat_a++ ; delete [] mat_a;
    mat_b++ ; delete [] mat_b;
    mat_c++ ; delete [] mat_c;
    rhs++ ; delete [] rhs ;
    sol++ ; delete [] sol ;
    gam++ ; delete [] gam;
    
}



void calc_epsilon_corr (double** epsilon1, double** epsilon0, double** rho, double** phi, double** res1, double** res0, double C1, double C2, double C3, double sigma_e, double** nu, double** nu_t0,double** nu_t1, double** k, double** delta_x, double** delta_y,  double* y_val, double** u_tau,int n, int m, int pm_res, grid cells, double dt) {
    
    
    
    double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;
    
    mat_a = new double[m];  mat_a--;
    mat_b = new double[m];  mat_b--;
    mat_c = new double[m];  mat_c--;
    rhs = new double[m]; rhs--;
    sol = new double[m]; sol--;
    gam = new double[m]; gam--;
    
    // flag detecting errors in tri_dag
    int flag = 0;
    
    
    //------------------
    // start
    //------------------
    
    
    for (int i=1 ; i<=n ; i++) {
        
        
        epsilon_constr_abc ( mat_a,  mat_b,  mat_c, m,  pm_res,  rho,  nu,  nu_t1,  sigma_e, phi,C2, delta_x,delta_y,y_val,u_tau, cells, i,  dt,n);
        epsilon_constr_rhs_corr(rhs, m, pm_res,  epsilon0,  res1,  res0, rho,  phi, nu,  nu_t0,  sigma_e,C2, delta_x,delta_y,y_val, u_tau,cells,  i, dt,n);
        
        tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;
        
        for (int j=1 ; j<=m ; j++)
            epsilon1[i][j] = sol[j] ;
        
    }
    
        
    if (flag == 1)
        cout << "ERROR IN calc_epsilon_corr" << endl;
    
    
    mat_a++ ; delete [] mat_a;
    mat_b++ ; delete [] mat_b;
    mat_c++ ; delete [] mat_c;
    rhs++ ; delete [] rhs ;
    sol++ ; delete [] sol ;
    gam++ ; delete [] gam;
    
    
}


void res_epsilon_compu(double** res_epsilon, double** f1, double** f2, double** epsilon, double** rho, double** phi, double** u, double** v, double C1, double C2, double C3,double sigma_e, double** nu,double** nu_t, double** delta_x, double** delta_y, double** k,double* y_val, double** u_tau, grid cells, int n, int m) {
    
    double conva, convb, conv_term ;
    double diffa, diffb, diff_term ;
    double normS, terme_res, terme_res2,eta;
    double** mu_t;
    double res_max=0;
    mu_t= matrix_np(n+2,m+2) ;
    double** val_v;
    val_v= matrix_np(n+2,m+2) ;
    double** f3;
    f3= matrix_np(n+2,m+2) ;
    for (int i=0 ; i<=n+1 ; i++){
        for (int j=0 ; j<=m+1 ; j++){
            val_v[i][j] =(nu[i][j]+ nu_t[i][j]/sigma_e);
            mu_t[i][j]= nu_t[i][j]*rho[i][j];
            f3[i][j]=1.-0.22*exp(-k[i][j]*k[i][j]*k[i][j]*k[i][j]/36./nu[i][j]/nu[i][j]/epsilon[i][j]/epsilon[i][j]);
            
        }
    }
    //  double diffb ;
    
    cell pt ;
    
    
    
    for (int i=1 ; i<=n ; i++) {
        for (int j=1 ; j<=m ; j++) {
            
            pt.i = i;
            pt.j = j;
            
            // convective term
            
            conva = ( f1[i][j] * derxfor(epsilon, pt, cells) + f1[i-1][j] * derxback(epsilon, pt, cells) ) /2. ;
            
            convb = ( f2[i][j] * derytop(epsilon, pt, cells) + f2[i][j-1] * derybot(epsilon, pt, cells) ) /2. ;
            
            conv_term = -(conva + convb) ;
            
            
            // diffusive term
            
            diffa = valfor(phi,val_v, pt,cells) * derxfor(epsilon, pt, cells) /2. /cells.ri[i]  ;
            
            diffb = valback(phi,val_v, pt,cells) * derxback(epsilon, pt,cells) /2. /cells.ri[i] ;
            
            
            diff_term = rho[i][j]/Re * (diffa - diffb) ;
            
            // termes avec constantes C1, C2 et C5
            
            //if (k[i][j] < 1e-14){
               // coeff_C1=0.;
                //coeff_C2=0.;
               // termeC3=0.;
           // }
            //else {
               // coeff_C1=C1*mu_t[i][j]*phi[i][j]*epsilon[i][j]/k[i][j]/Re;
               // coeff_C2= -2.*C2*epsilon[i][j]/k[i][j]/rho[i][j]/Re*mu_t[i][j];
               // termeC3= -C3*f3[i][j]*rho[i][j]*epsilon[i][j]* epsilon[i][j]* phi[i][j]/k[i][j];
              //termeC3=
            //}
            normS= derx(u,pt,cells)*derx(u,pt,cells) +1./2.* (dery(u,pt,cells) + derx(v,pt,cells))*(dery(u,pt,cells) + derx(v,pt,cells))+dery(v,pt,cells)*dery(v,pt,cells);
            eta= k[i][j]/epsilon[i][j]* sqrt(2.*normS);
            C1= max(0.43,eta/(eta+5));
            
            //termeC1a= coeff_C1*( 2.* derx(u,pt,cells)*derx(u,pt,cells)+ 2.*
                               // dery(v,pt,cells)*dery(v,pt,cells)+ (dery(u,pt,cells) + derx(v,pt,cells))*(dery(u,pt,cells) + derx(v,pt,cells)));
            
            terme_res= C1*rho[i][j]* epsilon[i][j]*sqrt(2.*normS)*phi[i][j];
            //termeC1b= -2./3.*C1*phi[i][j]*epsilon[i][j]*rho[i][j]*( derx(u,pt,cells)+ dery(v,pt,cells));
            terme_res2= -C3*rho[i][j]*phi[i][j]*epsilon[i][j]*epsilon[i][j]/ ( k[i][j]+sqrt(nu[i][j]*epsilon[i][j]));
            
            //termeC1c= -2/3.* coeff_C1*( derx(u,pt,cells) + dery(v,pt,cells))*( derx(u,pt,cells) + dery(v,pt,cells));
            
            //termeC2a=coeff_C2*(delta_x[i][j]*derx(u,pt,cells)+delta_y[i][j]*dery(v,pt,cells));
            
            
            
           // termeC2c= -coeff_C2/3.*(delta_x[i][j]+delta_y[i][j])*( derx(u,pt,cells)+ dery(v,pt,cells));
            
            
            
            res_epsilon[i][j] = conv_term + diff_term + terme_res+ terme_res2;
            //res_max=max(res_max,abs(termeC3));
        }
    }
   //printf("\n res = %f, convterm = %f, diffterm = %f, termeC1a = %f, termeC1b = %f,  termeC2a = %f,termeC1c = %f,termeC2c = %f \n", res_epsilon[100][100],conv_term,diff_term,termeC1a,termeC1b,termeC2a,termeC1c,termeC2c);
     printf("\n termc3 = %f \n", res_max);
    delmat_np(val_v, n+2,m+2);
    delmat_np(mu_t, n+2,m+2);
    delmat_np(f3, n+2,m+2);
    
        }

                                
void epsilon_constr_abc ( double* a, double* b, double* c, int m, int pm_res, double** rho, double** nu, double** nu_t1, double sigma_e, double** phi, double C2, double** delta_x, double** delta_y,double* y_val, double** u_tau, grid cells, int i, double dt, int n) {

  double alpha, betta;
  double** val_v;
  val_v= matrix_np(n+2,m+2) ;
    for (int i=0; i<=n+1 ; i++)
        for (int j=0; j<=m+1 ; j++)
             val_v[i][j] =(nu[i][j]+ nu_t1[i][j]/sigma_e);

  cell pt;

  pt.i = i;

  for (int j=1 ; j<=m ; j++) {

    pt.j = j ;

        alpha = 0.5 /Re * dt * valtop(phi,val_v, pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j+1]) ;

        betta = 0.5 /Re * dt * valbot(phi,val_v,pt,cells) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j-1]) ;

    a[j] = - betta*rho[i][j] ;

    c[j] = - alpha*rho[i][j] ;

      b[j] = rho[i][j] * phi[i][j] + alpha*rho[i][j] + betta*rho[i][j];// + dt*rho[i][j]*nu[i][j]*exp(-0.5*u_tau[i][1]/nu[i][j]*y_val[j])/y_val[j]/y_val[j]  ;

  }

  if (Bcomb_epsilon_b == 'o')
      // lower boundary
      b[1] += a[1];
  else if (Bcomb_epsilon_t == 'o')
      // upper boundary
      b[m] += c[m];
  
  else if (Bcomb_epsilon_b == 'd'|| Bcomb_epsilon_b == 'w')
      // lower boundary
      b[1] -= a[1];
    else if (Bcomb_epsilon_t == 'd' || Bcomb_epsilon_t == 'w')
      // upper boundary
      b[m] -= c[m];
  
  else
      cout << endl << "ERROR in the choice of bcomb_epsilon_t, in file epsilon_calc.cpp" << endl;

     delmat_np(val_v, n+2,m+2);
}

void epsilon_constr_rhs_pred (double* r, int m, int pm_res, double** epsilon, double** res1, double** res0, double** rho, double** phi,double** nu, double** nu_t0, double sigma_e, double C2, double** delta_x, double** delta_y,double* y_val, double** u_tau,grid cells, int i, double dt,int n) {

  double term_n, term_s ;
    double** val_v;
    val_v= matrix_np(n+2,m+2) ;
    for (int i=0 ; i<=n+1 ; i++)
        for (int j=0 ; j<=m+1 ; j++)
             val_v[i][j] =(nu[i][j]+ nu_t0[i][j]/sigma_e);


  cell pt;

  pt.i = i ;

  for (int j=1 ; j<=m ; j++) {

      pt.j = j;

      term_n = valtop(phi,val_v, pt,cells) * derytop(epsilon, pt,cells) /2. /cells.rj[j] ;

      term_s = valbot(phi, val_v,pt,cells) * derybot(epsilon, pt,cells) /2. /cells.rj[j] ;


      r[j] = rho[i][j] * phi[i][j] * epsilon[i][j]  + 1.5*dt*res1[i][j] - 0.5*dt*res0[i][j] +
      + dt*0.5 /Re * rho[i][j]*(term_n - term_s);// - dt*rho[i][j]*nu[i][j]*epsilon[i][j]/y_val[j]/y_val[j]* exp(-0.5*u_tau[i][1]*y_val[j]/nu[i][j])  ;

  }

  

  if (Bcomb_epsilon_b == 'd' ||Bcomb_epsilon_b == 'w' ) {

    pt.j = 1;
    r[1] += 2. * epsilon_val_b * 0.5 *dt /Re *rho[1][1] * valbot(phi,val_v, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;
  }
   else if (Bcomb_epsilon_t == 'd' || Bcomb_epsilon_t == 'w'){
    pt.j = m ;
    r[m] += 2. * epsilon_val_t * 0.5 *dt /Re * rho[1][1]*valtop(phi,val_v, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);

  }
    
//printf("\n termn = %f \n", term_n);
 delmat_np(val_v, n+2,m+2);
}


void epsilon_constr_rhs_corr (double* r, int m, int pm_res, double** epsilon, double** res1, double** res0, double** rho, double** phi,double** nu, double** nu_t0, double sigma_e, double C2, double** delta_x, double** delta_y,double* y_val, double** u_tau, grid cells, int i, double dt,int n) {

  double term_n, term_s ;
    double** val_v;
    val_v= matrix_np(n+2,m+2) ;
       for (int i=0 ; i<=n+1 ; i++)
           for (int j=0; j<=m+1 ; j++)
                val_v[i][j] =(nu[i][j]+ nu_t0[i][j]/sigma_e);

  cell pt;

  pt.i = i ;

  for (int j=1 ; j<=m ; j++) {

      pt.j = j;

      term_n = valtop(phi,val_v, pt,cells) * derytop(epsilon, pt,cells) /2. /cells.rj[j] ;

      term_s = valbot(phi,val_v, pt,cells) * derybot(epsilon, pt,cells) /2. /cells.rj[j] ;


    r[j] = rho[i][j] * phi[i][j] * epsilon[i][j] + 0.5*dt*res1[i][j] + 0.5*dt*res0[i][j]
      + dt*0.5*rho[i][j] /Re * (term_n - term_s);//- dt*rho[i][j]*nu[i][j]*epsilon[i][j]*exp(-0.5*u_tau[i][1]/nu[i][j]*y_val[j])/y_val[j]/y_val[j]  ;

  }

  

  if (Bcomb_epsilon_b == 'd' || Bcomb_epsilon_b == 'w') {

    pt.j = 1;
    r[1] += 2. * epsilon_val_b * 0.5 *dt /Re  *rho[1][1]* valbot(phi,val_v, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;
  }
    else if (Bcomb_epsilon_t == 'd'|| Bcomb_epsilon_t == 'w') {
    pt.j = m ;
    r[m] += 2. * epsilon_val_t * 0.5 *dt /Re * rho[1][1]*valtop(phi,val_v, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);

  }
 delmat_np(val_v, n+2,m+2);
}



