/*
 * k_calc.h
 *
 *  Created on: Jan 17, 2014
 *      Author: paant
 */

#ifndef K_CALC_H_
#define K_CALC_H_

#include <math.h>

#include "trivialfuncs.h"

#include "linsys_solvers.h"
#include "o_funcs.h"


void calc_k_pred (double** k1, double** k0, double** rho, double** res_k1, double** res_k0, double** phi, double** nu, double** nu_t0, double** nu_t1,double sigma_k,
                   double** delta_x, double** delta_y, double* y_val,double** epsilon0, int n, int m, int pm_res,double** val_v0, double** val_v1, grid cells, double dt);
void calc_k_corr (double** k1, double** k0, double** rho, double** res_k1, double** res_k0, double** phi, double** nu, double** nu_t0, double** nu_t1, double sigma_k,
                  double** delta_x, double** delta_y,double* y_val, double** epsilon0,double** val_v0, double** val_v1,int n, int m, int pm_res, grid cells, double dt);

void res_k_compu(double** res_k, double** f1, double** f2, double** k,double** epsilon, double** u, double** v, double** rho, double** phi,
                 double** delta_x, double** delta_y, double** nu, double** nu_t, double sigma_k,double* y_val,double** val_v, grid cells, int n, int m);
void k_constr_abc ( double* a, double* b, double* c, int pm_res, double** rho, double** phi, double** delta_x, double** delta_y, double** nu, double** nu_t, double sigma_k, double* y_val, double** epsilon0, double** k0,double** nu_tot,grid cells, int i, double dt, int n, int m);
void k_constr_rhs_pred (double* r, int pm_res, double** res1, double** res0, double** nu, double** nu_t, double sigma_k, double** rho, double** delta_x, double** delta_y,
                        double** k, double** phi,double* y_val, double** epsilon0, double** k0,double** nu_tot, grid cells, int i, double dt, int n, int m);
void k_constr_rhs_corr (double* r, int pm_res, double** k, double** res1, double** res0, double** nu, double** nu_t, double sigma_k, double** delta_x, double** delta_y,
                        double** rho, double** phi, double* y_val,double** epsilon0, double** k0,double** nu_tot, grid cells, int i, double dt, int n, int m);
#endif /* k_CALC_H_ */
