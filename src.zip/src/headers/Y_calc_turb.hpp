//
//  Y_calc.hpp
//  
//
//  Created by Sara Verheyleweghen on 29/02/2020.
//

#ifndef Y_calc_turb_hpp
#define Y_calc_turb_hpp

#include <stdio.h>
#include <math.h>

#include "trivialfuncs.h"

#include "linsys_solvers.h"
#include "o_funcs.h"



void calc_Y_pred_turb (double** Y1, double** Y0, double** temperature, double** rho, double** res_Y1, double** res_Y0, double** phi,double** D,double** Dt0,double** Dt1, double** nut, int n, int m, int pm_res, grid cells, double dt );

void calc_Y_corr_turb (double** Y1, double** Y0, double** temperature, double** rho, double** res_Y1, double** res_Y0, double** phi, double** D,double** Dt0,double** Dt1,double** nut, int n, int m, int pm_res, grid cells, double dt);

void res_Y_compu_turb(double** res_t, double** f1, double** f2, double** Y,  double** rho, double** phi, double** D,double** Dt, double ** nut, double** R, grid cells, int n, int m) ;

void Y_constr_abc_turb ( double* a, double* b, double* c, int m, int pm_res, double** rho, double** phi,double** D,double** Dt, grid cells, int i, double dt, int n);

void Y_constr_rhs_pred_turb (double* r, int m, int pm_res, double** Y, double** res1, double** res0, double** rho, double** phi, double** D,double** Dt, grid cells, int i, double dt,int n) ;

void Y_constr_rhs_corr_turb (double* r, int m, int pm_res, double** Y, double** res1, double** res0, double** rho, double** phi, double** D,double** Dt, grid cells, int i, double dt,int n); 



#endif /* Y_calc_hpp */
