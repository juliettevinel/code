/*
 * deformfuncs.h
 *
 *  Created on: Jan 29, 2014
 *      Author: paant
 */

#ifndef DEFORMFUNCS_TURB_H_
#define DEFORMFUNCS_TURB_H_

#include "global.h"

#include "trivialfuncs.h"

void deformcompu_turb (vec& tensor, double** u , double** v, double** phi, double** mu, double** mu_t, cell pt, grid cells) ;

#endif /* DEFORMFUNCS_H_ */
