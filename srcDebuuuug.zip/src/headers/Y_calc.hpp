//
//  Y_calc.hpp
//  
//
//  Created by Sara Verheyleweghen on 29/02/2020.
//

#ifndef Y_calc_hpp
#define Y_calc_hpp

#include <stdio.h>
#include <math.h>

#include "trivialfuncs.h"

#include "linsys_solvers.h"


void calc_Y_pred (double** Y1, double** Y0, double** temperature, double** rho, double** res_Y1, double** res_Y0, double** phi,double** D, int n, int m, int pm_res, grid cells, double dt );

void calc_Y_corr (double** Y1, double** Y0, double** temperature, double** rho, double** res_Y1, double** res_Y0, double** phi, double** D, int n, int m, int pm_res, grid cells, double dt);

void res_Y_compu(double** res_t, double** f1, double** f2, double** Y,  double** rho, double** phi, double** D,double** R, grid cells, int n, int m);

void Y_constr_abc ( double* a, double* b, double* c, int m, int pm_res, double** rho, double** phi,double** D, grid cells, int i, double dt);

void Y_constr_rhs_pred (double* r, int m, int pm_res, double** Y, double** res1, double** res0, double** rho, double** phi, double** D, grid cells, int i, double dt);

void Y_constr_rhs_corr (double* r, int m, int pm_res, double** Y, double** res1, double** res0, double** rho, double** phi, double** D, grid cells, int i, double dt);



#endif /* Y_calc_hpp */
