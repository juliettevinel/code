clear all;
close all;
clc;

plottype = 'epsprofile';
rate = 10;
%% Time
fileID = fopen('./data/tsteps.dat','r');
time = fscanf(fileID,'%f');
fclose(fileID);

files_t = dir('./reacting_v1/*t.txt');
[~,idx]=sort([files_t.datenum]);
files_t = files_t(idx);
n = size(files_t);

stepno = n(1);
filestep = time(3);

%% Grid
fileID = fopen('./data/grid.dat','r');
dim = fscanf(fileID,'%f');
fclose(fileID);

xf = dim(3);
yf = dim(4);
resx = dim(1);
resy = dim(2);

%Milieu poreux
pm_resx = dim(6)-dim(5)+1;
pm_resy = dim(8)-dim(7)+1;

%% Allocations
phi = zeros(resx,resy);
utilde = zeros(resx,resy);

ri = zeros(resx,resy);
rj = zeros(resx,resy);
centx = zeros(resx,resy);
centy = zeros(resx,resy);
centphi = zeros(resx,resy);

%Grid informations - because ri and rj can vary from cell to cell
ri_file = fopen('./grid/ri.txt','r');
ri = reshape (fread(ri_file,'double'),[resx resy]);
fclose(ri_file);
rj_file = fopen('./grid/rj.txt','r');
rj = reshape (fread(rj_file,'double'),[resx resy]);
fclose(rj_file);

centx_file = fopen('./grid/centx.txt','r');
centx = reshape (fread(centx_file,'double'),[resx resy]);
fclose(centx_file);
centy_file = fopen('./grid/centy.txt','r');
centy = reshape (fread(centy_file,'double'),[resx resy]);
fclose(centy_file);
cornx_file = fopen('./grid/cornx.txt','r');
cornx = reshape (fread(cornx_file,'double'),[resx+1 resy+1]);
fclose(cornx_file);
corny_file = fopen('./grid/corny.txt','r');
corny = reshape (fread(corny_file,'double'),[resx+1 resy+1]);
fclose(corny_file);

%Initial conditions
centphi_file = fopen('./init/centphi.txt','r');
centphi = reshape (fread(centphi_file,'double'),[resx resy]);
fclose(centphi_file);

%centtemp_file = fopen('./init/centtemp.txt','r');
%centtemp = reshape (fread(centtemp_file,'double'),[resx resy]);
%fclose(centtemp_file);

centu_file = fopen('./init/centu.txt','r');
 %centu = reshape (fread(centu_file,'double'),[resx resy]);
% fclose(centu_file);


M = fread(centu_file,'double');
var_f = reshape(M,[resx resy])';
fig_var = figure;
set(gcf, 'Position', [100 100 600 400]);
imagesc(var_f);
set(gca,'YDir','normal')
c = colorbar;
frame = getframe(fig_var);
fclose(centu_file);
figure;
plot(var_f(:,20),linspace(0,200,length(var_f(:,20))));

centu_file = fopen('./init/centv.txt','r');
 %centu = reshape (fread(centu_file,'double'),[resx resy]);
 %fclose(centu_file);


M = fread(centu_file,'double');
var_f = reshape(M,[resx resy])';
 fig_var = figure;
 imagesc(var_f);
 set(gca,'YDir','normal')
 c = colorbar;
 frame = getframe(fig_var);
 fclose(centu_file);
% figure;
% plot(var_f(:,20),linspace(0,200,length(var_f(:,20))));



% figure;
% imagesc(centu);
% set(gca,'YDir','normal');
 
 
% centY_file = fopen('./init/centY.txt','r');
%
% M = fread(centY_file,'double');
% var_f = reshape(M,[resx resy])';
% fig_var = figure;
% imagesc(var_f);
% set(gca,'YDir','normal')
% frame = getframe(fig_var);
% fclose(centY_file);
% colorbar;
%
centphi_file = fopen('./init/centphi.txt','r');

M = fread(centphi_file,'double');
var_f = reshape(M,[resx resy])';
fig_var = figure;
set(gcf, 'Position', [100 100 600 400]);
imagesc(var_f);
set(gca,'YDir','normal')
frame = getframe(fig_var);
fclose(centphi_file);
colorbar;




%% Results
rho = zeros(resx+2,resy+2);
Y = zeros(resx+2,resy+2);
temp = zeros(resx+2,resy+2);
p = zeros(resx+2,resy+2);
u = zeros(resx+2,resy+2);
v = zeros(resx+2,resy+2);

%close all;

%% Plot

fig = figure;
set(gcf, 'Position', [100 100 600 400]);
a = 0;
for stepp = [filestep filestep:filestep:stepno*filestep]
    %phis_file = fopen(strcat('./laminar_VI/0phi_s_db.txt'),'r');
    %phi_s = reshape (fread(phis_file,'double'),[pm_resx+2 pm_resy+2 pm_resz+2]);
    %fclose(phis_file);
    
    %%%Round garbage errors
    digit = 1e13;

 t_file = fopen(strcat('./reacting_V1/',num2str(stepp),'t.txt'),'r');
     t = fscanf(fileID,'t = %f'); 
    fclose(t_file);

    
    if strcmp(plottype,'Y')
        Y_file = fopen(strcat('./reacting_V1/',num2str(stepp),'Y_db.txt'),'r');
        Y = reshape (fread(Y_file,'double'),[resx+2 resy+2]);
        fclose(Y_file);
        Y = round(digit *Y) / digit;
        
        imagesc((Y(2:end-1,2:end-1))');
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('Dispersion of the pollutants, t = ',num2str(t)));
    end
    if strcmp(plottype,'k')
        Y_file = fopen(strcat('./reacting_V1/',num2str(stepp),'k_db.txt'),'r');
        Y = reshape (fread(Y_file,'double'),[resx+2 resy+2]);
        fclose(Y_file);
        Y = round(digit *Y) / digit;
        
%                 %creer fixier txt
%         k_BC = Y(500,2:end-1); 
%         %u_BC= u_BC(end:-1:1);
%         fid = fopen('kdummy.txt', 'w');
%         fprintf(fid, '%f\n', k_BC.');
%          fclose(fid);
        
        imagesc((Y(2:end-1,2:end-1))');
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('Turbulent kinetic energy, t = ',num2str(t)));
    end
    if strcmp(plottype,'kprofile')
        k_file = fopen(strcat('./reacting_V1/',num2str(stepp),'k_db.txt'),'r');
        k = reshape (fread(k_file,'double'),[resx+2 resy+2]);
        fclose(k_file);
        k = round(1e11*k) / 1e11;
        u_file = fopen(strcat('./reacting_V1/',num2str(stepp),'u_db.txt'),'r');
        u = reshape (fread(u_file,'double'),[resx+2 resy+2]);
        fclose(u_file);
        u = round(1e11*u) / 1e11;
        
        plot(k(300,2:end-1),centy(300,:));
     
        xlabel('k')
        ylabel('Non-D y')
        title(strcat('Turbulent kinetic energy, t = ',num2str(t)));
    end
    if strcmp(plottype,'eps')
        Y_file = fopen(strcat('./reacting_V1/',num2str(stepp),'epsilon_db.txt'),'r');
        Y = reshape (fread(Y_file,'double'),[resx+2 resy+2]);
        fclose(Y_file);
        Y = round(digit *Y) / digit;
        
%         %creer fixier txt
%         eps_BC = Y(500,2:end-1); 
%         %u_BC= u_BC(end:-1:1);
%         fid = fopen('epsdummy.txt', 'w');
%         fprintf(fid, '%f\n', eps_BC.');
%         fclose(fid);
        
        imagesc((Y(2:end-1,2:end-1))');
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('Turbulence dissipation rate, t = ',num2str(t)));
    end
    if strcmp(plottype,'epsprofile')
        u_file = fopen(strcat('./reacting_V1/',num2str(stepp),'epsilon_db.txt'),'r');
        u = reshape (fread(u_file,'double'),[resx+2 resy+2]);
        fclose(u_file);
        u = round(1e11*u) / 1e11;
        
        plot(u(300,2:end-1),centy(300,:));
     
        xlabel('Dissipation rate')
        ylabel('Non-D y')
        title(strcat('\epsilon, t = ',num2str(t)));
    end
    if strcmp(plottype,'vorticity')
        dudy_file = fopen(strcat('./reacting_V1/',num2str(stepp),'dudy.txt'),'r');
        dudy = reshape (fread(dudy_file,'double'),[resx resy]);
        fclose(dudy_file);
        dudy = round(1e11*dudy) / 1e11;
        
        dvdx_file = fopen(strcat('./reacting_V1/',num2str(stepp),'dvdx.txt'),'r');
        dvdx = reshape (fread(dvdx_file,'double'),[resx resy]);
        fclose(dvdx_file);
        dvdx = round(1e11*dvdx) / 1e11;
        
        contour(centx(:,:) ,centy(:,:),abs(dvdx-dudy),[5,10,15,20,30,40,50,60]);
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
       title(strcat('Vorticity, t = ',num2str(t)));
    end
    if strcmp(plottype,'nut')
 %       v_file = fopen(strcat('./reacting_V1/',num2str(stepp),'nut_db.txt'),'r');
%         v = reshape (fread(v_file,'double'),[resx+2 resy+2]);
%         fclose(v_file);
%         v = round(1e11 *v) / 1e11;
        k_file = fopen(strcat('./reacting_V1/',num2str(stepp),'nut_db.txt'),'r');
        k = reshape (fread(k_file,'double'),[resx+2 resy+2]);
        fclose(k_file);
        imagesc(k(2:end-1,2:end-1)');
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('nu_t, t = ',num2str(t)));
     end
    
    if strcmp(plottype,'T')
        Y_file = fopen(strcat('./reacting_V1/',num2str(stepp),'temp_db.txt'),'r');
        Y = reshape (fread(Y_file,'double'),[resx+2 resy+2]);
        fclose(Y_file);
        Y = round(digit *Y) / digit;

        imagesc((Y(2:end-1,2:end-1))');
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('Temperature, t = ',num2str(t)));
    end
    if strcmp(plottype,'density')
        rho_file = fopen(strcat('./reacting_V1/',num2str(stepp),'rho_db.txt'),'r');
        rho = reshape (fread(rho_file,'double'),[resx+2 resy+2]);
        fclose(rho_file);
        rho = round(digit *rho) / digit;
        
        contourf(centx(:,:) ,centy(:,:),rho(2:end-1,2:end-1));
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('Density, t = ',num2str(t)));
    end
    
    if strcmp(plottype,'pressure')
        p_file = fopen(strcat('./reacting_V1/',num2str(stepp),'p_db.txt'),'r');
        p = reshape (fread(p_file,'double'),[resx+2 resy+2]);
        fclose(p_file);
        p = round(digit *p) / digit;
        
        %imagesc(p(2:end-1,2:end-1))
        contourf(centx(:,:) ,centy(:,:),p(2:end-1,2:end-1));
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('Pressure, t = ',num2str(t)));
    end
    
    if strcmp(plottype,'uvel')
   
       u_file = fopen(strcat('./reacting_V1/',num2str(stepp),'u_db.txt'),'r');
        u = reshape (fread(u_file,'double'),[resx+2 resy+2]);
        fclose(u_file);
        u = round(1e11*u) / 1e11;

%         %creer fixier txt
%         u_BC = u(end,2:end-1); 
%         %u_BC= u_BC(end:-1:1);
%         fid = fopen('udummy.txt', 'w');
%         fprintf(fid, '%f\n', u_BC.');
%         fclose(fid);
        
     
        %contourf(centx(:,:) ,centy(:,:),u(2:end-1,2:end-1));
        imagesc(u(2:end-1,2:end-1)');
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('u, t = ',num2str(t)));
    end
    
    if strcmp(plottype,'uprofile')
        u_file = fopen(strcat('./reacting_V1/',num2str(stepp),'u_db.txt'),'r');
        u = reshape (fread(u_file,'double'),[resx+2 resy+2]);
        fclose(u_file);
        u = round(1e11*u) / 1e11;
        
        plot(u(200,2:end-1),centy(200,:));
     
        xlabel('u')
        ylabel('Non-D y')
        title(strcat('u, t = ',num2str(t)));
    end
    
    if strcmp(plottype,'vvel')
        v_file = fopen(strcat('./reacting_V1/',num2str(stepp),'v_db.txt'),'r');
        v = reshape (fread(v_file,'double'),[resx+2 resy+2]);
        fclose(v_file);
        v = round(1e11 *v) / 1e11;
        
        imagesc(v(2:end-1,2:end-1)');
        colorbar;
        xlabel('Non-D x')
        ylabel('Non-D y')
        title(strcat('v, t = ',num2str(t)));
    end

 if stepp == filestep && a == 0
            % Frame
            set(gca,'YDir','normal')
            c = colorbar;
            frame = getframe(fig);
            
            %Creating video file
           videoObj = VideoWriter(sprintf('./videos/%s.avi',plottype),'MPEG-4');
            videoObj.FrameRate = rate;
            open(videoObj);
            a = 1;
        else
            writeVideo(videoObj,frame);
            set(gca,'YDir','normal')
            %c = colorbar;
            frame = getframe(fig);
        end
    end
    close(videoObj);

