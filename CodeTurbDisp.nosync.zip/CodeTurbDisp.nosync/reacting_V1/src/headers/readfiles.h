/*
 * readfiles.h
 *
 *  Created on: Apr 15, 2011
 *      Author: paant
 */

#ifndef READFILES_H_
#define READFILES_H_

#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>


using namespace std;


double readdouble(string file);
int readint(string file);
char readchar(string file);


#endif /* READFILES_H_ */
