/*
 * matric_a_e.h
 *
 *  Created on: June 9, 2020
 *      Author: sverhey
 */

#ifndef MATRIC_A_E_H_
#define MATRIC_A_E_H_


#include <math.h>
#include <iostream>


//#include "global.h"
#include "trivialfuncs.h"
#include "matrixab.h"


using namespace std;

void constr_a_e (double* a, int* pos, double* precond, double** phi, int n, int m, grid cells,double dt, double* Uc );
void constr_b_e (double* output, double** utilde_i, double** utilde_j, double** rho1, double** rho0, double** rho_new, double** phi1, double** phi0, double** phi_new, double** M_re, int n , int m , double* y_val, grid cells, double dt, double* Uc, double** pression0) ;


#endif /* MATRIXAB_H_ */
