/*
 * utilde_calc.h
 *
 *  Created on: Jan 27, 2014
 *      Author: paant
 */

#ifndef UTILDE_TURB_CALC_H_
#define UTILDE_TURB_CALC_H_

#include "global.h"
#include "linsys_solvers.h"
#include "trivialfuncs.h"

void calc_utilde_turb_pred (double** utilde_i, double** utilde_j, double** u, double** v, double** resu1, double** resv1, double** resu0, double** resv0, double** p, 
							double** rho_st, double** rho_n, double** mu,double** mu_t0,double** mu_t1, double** phist, double** phin, double** delta_x, double** delta_y, 
							double* y_val, grid cells, int n, int m, double dt, int& flagc);

void calc_utilde_turb_corr (double** utilde_i, double** utilde_j, double** u_n, double** v_n, double** resu1, double** resv1, double** resu0, double** resv0,
                            double** p, double** rhonp1, double** rho1, double** mu, double** mu_t0, double** mu_t1, double** phinp1, double** phin, double** delta_x, double** delta_y, double* y_val, grid cells, int n, int m, double dt, int& flagc);

void ut_constr_turb_abc (double* a, double* b, double* c, int m, double** rho, double** phi, double** mu, double** mu_t, double** delta, grid cells, int i, double dt);
void ut_constr_rhs_turb_pred ( double* r, int m, double** u, double** res1, double** res0, double** p, double** rho, double** phi, double**  delta, double** mu, double** mu_t, grid cells, double y_top, int i, double dt );
void ut_constr_rhs_turb_corr ( double* r, int m, double** u, double** res1, double** res0, double** p, double** rho, double** phi, double**  delta, double** mu, double** mu_t, grid cells, double y_top, int i, double dt );
void vt_constr_turb_abc (double* a, double* b, double* c, int m, double** rho, double** phi, double** mu, double** mu_t, double** delta, grid cells, int i, double dt) ;
void vt_constr_rhs_turb_pred ( double* r, int m, double** v, double** res1, double** res0, double** rho, double** phi, double**  delta, double** mu, double** mu_t, grid cells, int i, double dt );
void vt_constr_rhs_turb_corr ( double* r, int m, double** v, double** res1, double** res0, double** rho, double** phi, double**  delta, double** mu, double** mu_t, grid cells, int i, double dt );

#endif /* UTILDE_CALC_H_ */
