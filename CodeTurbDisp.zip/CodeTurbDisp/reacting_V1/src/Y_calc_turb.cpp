//
//  Y_calc_turb.cpp
//  
//
//  Created by Juliette Vinel on 08/04/2020.
//

#include "./headers/Y_calc_turb.hpp"

void calc_Y_pred_turb (double** Y1, double** Y0, double** temperature, double** rho, double** res_Y1, double** res_Y0, double** phi,double** D, double** D_t0, double** D_t1, int n, int m, int pm_res, grid cells, double dt ){

    double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;
    double epsilon = 0.0000000001;
    
        mat_a = new double[m];  mat_a--;
        mat_b = new double[m];  mat_b--;
        mat_c = new double[m];  mat_c--;
        rhs = new double[m]; rhs--;
        sol = new double[m]; sol--;
        gam = new double[m]; gam--;

        // flag detecting errors in tri_dag
        int flag = 0;

        //------------------
        // start
        //------------------
		


        for (int i=1 ; i<=n ; i++) {

          Y_constr_abc_turb (mat_a, mat_b, mat_c, m, pm_res, rho, phi,D,D_t1, cells, i, dt) ;
          Y_constr_rhs_pred_turb ( rhs, m, pm_res, Y0, res_Y1, res_Y0, rho, phi,D,D_t0, cells, i , dt) ;

          tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;

         for (int j=1 ; j<=m ; j++){
              if (sol[j]>1-epsilon)
                  Y1[i][j] = 1.;
              else if (sol[j]<epsilon)
                  Y1[i][j] = 0.;
              else
                  Y1[i][j] = sol[j] ;}

        }


        if (flag == 1)
          cout << "ERROR IN calc_Y_pred" << endl;

        mat_a++ ; delete [] mat_a;
        mat_b++ ; delete [] mat_b;
        mat_c++ ; delete [] mat_c;
        rhs++ ; delete [] rhs ;
        sol++ ; delete [] sol ;
        gam++ ; delete [] gam;
    }



void calc_Y_corr_turb (double** Y1, double** Y0, double** temperature, double** rho, double** res_Y1, double** res_Y0, double** phi, double** D, double** D_t0, double** D_t1, int n, int m, int pm_res, grid cells, double dt) {



    double *mat_a, *mat_b, *mat_c, *rhs, *sol, *gam ;
    double epsilon = 0.000000001;
    
    mat_a = new double[m];  mat_a--;
    mat_b = new double[m];  mat_b--;
    mat_c = new double[m];  mat_c--;
    rhs = new double[m]; rhs--;
    sol = new double[m]; sol--;
    gam = new double[m]; gam--;

    // flag detecting errors in tri_dag
    int flag = 0;


    //------------------
    // start
    //------------------


    for (int i=1 ; i<=n ; i++) {

     Y_constr_abc_turb (mat_a, mat_b, mat_c, m, pm_res, rho, phi,D,D_t1, cells, i, dt) ;
      Y_constr_rhs_pred_turb ( rhs, m, pm_res, Y0, res_Y1, res_Y0, rho, phi,D,D_t0, cells, i , dt) ;

      tridag (mat_a, mat_b, mat_c, rhs, sol, m, gam, flag, i) ;

     for (int j=1 ; j<=m ; j++){
          if (sol[j]>1-epsilon)
              Y1[i][j] = 1.;
          else if (sol[j]<epsilon)
              Y1[i][j] = 0.;
          else
              Y1[i][j] = sol[j] ;}

      }

    if (flag == 1)
      cout << "ERROR IN calc_Y_corr" << endl;

    mat_a++ ; delete [] mat_a;
    mat_b++ ; delete [] mat_b;
    mat_c++ ; delete [] mat_c;
    rhs++ ; delete [] rhs ;
    sol++ ; delete [] sol ;
    gam++ ; delete [] gam;

}


void res_Y_compu_turb(double** res_t, double** f1, double** f2, double** Y,  double** rho, double** phi, double** D,double** D_t,double** R, grid cells, int n, int m) {

  double conva, convb, conv_term ;
  double diffa, diffb,  diff_term ;

  //  double diffb ;

  cell pt ;

  for (int i=1 ; i<=n ; i++) {
    for (int j=1 ; j<=m ; j++) {

        pt.i = i;
        pt.j = j;

        // convective term

    conva = ( f1[i][j] * derxfor(Y, pt, cells) + f1[i-1][j] * derxback(Y, pt, cells) ) /2. ;

    convb = ( f2[i][j] * derytop(Y, pt, cells) + f2[i][j-1] * derybot(Y, pt, cells) ) /2. ;

    conv_term = - (conva + convb) ;


            // diffusive term

      diffa = (valfor(phi,D, pt,cells) + valfor(phi,D_t, pt,cells))* derxfor(Y, pt, cells) /2. /cells.ri[i]  ;

      diffb = (valback(phi,D, pt,cells) + valback(phi,D_t, pt,cells)) * derxback(Y, pt,cells) /2. /cells.ri[i] ;

      
      diff_term = 1./Re /Sc * rho[i][j]*(diffa - diffb) ;
      
      
      res_t[i][j] = conv_term + diff_term + rho[i][j]*phi[i][j] * R[i][j];

    }
  }

}


void Y_constr_abc_turb ( double* a, double* b, double* c, int m, int pm_res, double** rho, double** phi,double** D,double** D_t, grid cells, int i, double dt) {

  double alpha, betta;

  cell pt;

  pt.i = i;

  for (int j=1 ; j<=m ; j++) {

    pt.j = j ;

        alpha = 0.5 /Re /Sc * dt * (valtop(phi,D, pt,cells)+valtop(phi,D_t, pt,cells)) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j+1]) ;

        betta = 0.5 /Re /Sc * dt * (valbot(phi,D, pt,cells)+valbot(phi,D_t, pt,cells)) /2. /cells.rj[j] /(cells.rj[j] + cells.rj[j-1]) ;

    a[j] = - betta*rho[i][j] ;

    c[j] = - alpha *rho[i][j];

    b[j] = rho[i][j] * phi[i][j] + alpha*rho[i][j] + betta*rho[i][j] ;

  }

  if (Bcomb_Yt == 'o'){
      // lower boundary
      b[1] += a[1];
      // upper boundary
      b[m] += c[m];
  }
  else if (Bcomb_Yt == 'd') {
      // lower boundary
      b[1] -= a[1];
      // upper boundary
      b[m] -= c[m];
  }
  else
      cout << endl << "ERROR in the choice of bcomb_Yt, in file Y_calc.cpp" << endl;

}

void Y_constr_rhs_pred_turb (double* r, int m, int pm_res, double** Y, double** res1, double** res0, double** rho, double** phi, double** D,double** D_t, grid cells, int i, double dt) {

  double term_n, term_s ;

  cell pt;

  pt.i = i ;

  for (int j=1 ; j<=m ; j++) {

      pt.j = j;

      term_n = (valtop(phi,D, pt,cells)+valtop(phi,D_t, pt,cells)) * derytop(Y, pt,cells) /2. /cells.rj[j] ;

      term_s = (valbot(D, pt,cells)+valbot(D_t, pt,cells)) * derybot(Y, pt,cells) /2. /cells.rj[j] ;
      //    }

    r[j] = rho[i][j]*phi[i][j] * Y[i][j]  + 1.5*dt*res1[i][j] - 0.5*dt*res0[i][j] + dt*0.5/ Re/Sc * rho[i][j]*(term_n - term_s) ;

  }

  if (Bcomb_Yt == 'd') {

    pt.j = 1;
    r[1] += 2. * Yval_b * 0.5 *dt /Re /Sc *rho[1][1] * valbot(phi,D, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;

    pt.j = m ;
    r[m] += 2. * Yval_t * 0.5 *dt /Re /Sc *rho[1][1] * valtop(phi,D, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);

  }

}


void Y_constr_rhs_corr_turb (double* r, int m, int pm_res, double** Y, double** res1, double** res0, double** rho, double** phi, double** D,double** D_t, grid cells, int i, double dt) {

  double term_n, term_s ;

  cell pt;

  pt.i = i ;

  for (int j=1 ; j<=m ; j++) {

      pt.j = j;

      term_n = (valtop(phi,D, pt,cells)+valtop(phi,D_t, pt,cells)) * derytop(Y, pt,cells) /2. /cells.rj[j] ;

      term_s = (valbot(D, pt,cells)+valbot(D_t, pt,cells)) * derybot(Y, pt,cells) /2. /cells.rj[j] ;


    r[j] =  rho[i][j] * phi[i][j] * Y[i][j] + 0.5*dt*res1[i][j] + 0.5*dt*res0[i][j]
         + dt*0.5/Re/Sc * rho[i][j]*(term_n - term_s) ;

  }

  

  if (Bcomb_Yt == 'd') {

    pt.j = 1;
    r[1] += 2. * Yval_b * 0.5 *dt /Re /Sc *rho[1][1]* valbot(phi,D, pt,cells) /2. /cells.rj[1] /(cells.rj[1] + cells.rj[0]) ;

    pt.j = m ;
    r[m] += 2. * Yval_t * 0.5 *dt /Re /Sc *rho[1][1]* valtop(phi,D, pt,cells) /2. /cells.rj[m] /(cells.rj[m] + cells.rj[m+1]);

  }

}


